<?php
class sql
{
    private $conn;
    private $host="localhost";
    private $user="root";
    private $password="";
    private $db="design";
    function __construct(){
        $this->conn=mysqli_connect($this->host,$this->user,$this->password,$this->db);
        if (!$this->conn){
            echo "����ʧ��";
        }
        mysqli_query($this->conn,"set names gb2312");
    }
    //��ѯ������¼
    public function execute_dbl($sql)
    {
        $result=mysqli_query($this->conn, $sql);
        $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
        return $row;
    }
    //��ѯ������¼
    public function fetchAll($sql)
    {
        $result=mysqli_query($this->conn, $sql);
        $rows=array();
        while ($row=mysqli_fetch_array($result,MYSQLI_ASSOC))
        {
            $rows[]=$row;
        }
        return $rows;
    }
    //��ɾ��
    public function execute_dm($sql)
    {
        $result=mysqli_query($this->conn, $sql);
        if (!$result)
        {
            return 0;
        }
        else
        {
            if (mysqli_affected_rows($this->conn)>0)
            {
                return 1;
            }
            else
            {
                return 2;
            }
        }
    }
}
?>
