<?php 
session_start();//����session
include 'db.php';//�������ݿ������ļ�
//�ж��Ƿ��û���¼
if (empty($_SESSION['user']))
{
	echo "<script> location.href='login.php'</script>";
}
?>
<html>
  <head>
    <title>�޸�</title>
  </head>
  
  <body>
   <form name="form3" method="post">  
     <table border="0px" width="600px" height="400px" align="center" cellpadding="0px" cellspacing="0px">
       <tr>
         <td align="center"><b>�޸�ȫ���û�����</b></td>
         <td><input type="text" name="pass"/></td>
       </tr> 
       <tr>
         <td align="center"><b>�޸��û���</b></td>
         <td><input type="text" name="name"/></td>
       </tr>
       <tr>
         <td align="center"><b>�޸�����</b></td>
         <td><input type="text" name="passwd"/></td>
       </tr>
       <tr>
         <td align="center"><b>�޸���ϵ��ʽ</b></td>
         <td><input type="text" name="num"/></td>
       </tr>
       <tr>
         <td align="center" colspan="2"><b>ע���û���Ų����޸ģ����޸ĸ�����Ϣʱ������д�޸������û�����</b></td>
       </tr>    
       <tr>
         <td colspan="2" align="center">
            <input type="submit" name="sure" value="ȷ���޸�" />
            <input type="reset" value="����" />
         </td>        
       </tr>
     </table>
   </form>
  </body>
</html>
<?php 
$conn=mysqli_connect("localhost","root","") or die('����ʧ��');
mysqli_select_db($conn,"design") or die('���ݿ�ѡ��ʧ��');
mysqli_query($conn,"set names gb2312");
$sql="select level from login where id ='$_GET[id]'";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($result);
if($row['level']=='0')
{
	echo "<script>alert('����Ա�û����ܱ��޸�');location.href='manage.php'</script>";
}
if(isset($_POST['sure']))
{
	$passall=$_POST['pass'];
	$name=$_POST['name'];
	$pass=$_POST['passwd'];
	$num=$_POST['num'];
	if($passall!=null)
	{
		$sql="update login set passwd='$passall'";
		$sqltool=new sql();
		$result=$sqltool->execute_dm($sql);
		if ($result)
			echo "<script>alert('�޸ĳɹ�');location.href='manage.php'</script>";
	}
	else 
	{
	if ($pass!="")
	{
		$sql="update login set passwd='$pass' where id='$_GET[id]'";
		$sqltool=new sql();
		$result=$sqltool->execute_dm($sql);
		if ($result)
		{
			echo "<script>alert('�޸ĳɹ�');location.href='manage.php'</script>";
		}
	}
	if($name!="")
	{
		$sql="update login set username='$name' where id='$_GET[id]'";
		$sqltool=new sql();
		$result=$sqltool->execute_dm($sql);
		if ($result)
		{
			echo "<script>alert('�޸ĳɹ�');location.href='manage.php'</script>";
		}
	}
	if($num!="")
	{
		$sql="update login set num='$num' where id='$_GET[id]'";
		$sqltool=new sql();
		$result=$sqltool->execute_dm($sql);
		if ($result)
		{
			echo "<script>alert('�޸ĳɹ�');location.href='manage.php'</script>";
		}
	}
	}
	if($pass==null&&$name==null&&$num==null) 
		echo "<script>alert('��û���޸��κ�����');location.href='manage.php'</script>";
}
?>