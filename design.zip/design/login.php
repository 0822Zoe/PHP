<?php 
session_start();//开启session
include 'db.php';//引入数据库链接文件
//清楚session
$_SESSION['user']=null;
?>
<!DOCTYPE html>
<html>
  <head>
    <title>登录</title>
    <style>
		<?php
		include 'style.css';
		?>
    </style> 

  </head>
  
  <body>
   <form name="form1" method="post">
   <div class="header" id="head">
        <div class="title">管理系统</div>
   </div>
   <div class="wrap" id="wrap">
      <div class="login">
          <div class="login1">
            <p class="p1">登录</p>
          </div>  
          <div class="login2">
            <img src="user.jpg" width="20" height="20" alt="">
            <input type="text" name=user placeholder="用户名">
          </div>
          <div class="login2">
             <img src="passwd.jpg" width="20" height="20" alt="">
             <input type="password" name=password placeholder="密码">
          </div>
          <div class="login3">
          	 <input type="text" name=check placeholder="验证码">
          	 <img src="code.php" width="100" height="30" onclick="this.src='code.php?aa='+Math.random()">
          </div>
          <div class="bt">
          <input type="submit" name="log" value="登录">
          </div>
          <div class="bt1">
          <input type="submit" name="reg" value="注册">
          </div>
      </div>
   </div>
   <div class="footer" id="foot">
     <div class="btm">
        <p>Copyright@ 2021 ustl xlz</p>
        <div class="ph">
        	<span>联系电话:15812345678</span>
        </div>
     </div>
   </div>
   </form>
  </body>
</html>

<?php 
//登录
if (isset($_POST['log']))
{
	$t1=$_POST['user'];
	$t2=$_POST['password'];
	$t3=$_POST['check'];
	if($t1!=null && $t2!=null && $t3!=null)
	{
		$conn=mysqli_connect("localhost","root","","design");
		mysqli_query($conn,"set names gb2312");
		$sql=" select * from login where username='$t1' and passwd='$t2'";
		$result=mysqli_query($conn,$sql);
		if(!$result)
		{
			die("操作失败".mysqli_error());
		}
		if($row=mysqli_fetch_row($result))
		{
			if(strtolower($t3)==strtolower($_SESSION['code']))//验证码不区分大小写
			{
				$_SESSION['user']=$t1;
				header("Location: media.php");
			}
			else 
			echo "<script>alert('验证码不正确');</script>";
		}
		else
		{
			echo "<script>if(confirm('登录失败')) ";
            echo "location.href='login.php'</script>";
		}
	}
	else
	echo "<script>alert('用户名或密码或验证码不能为空！')</script>";
}
if (isset($_POST['reg']))
{
	header("Location: register.php");
}
header('Content-Type:text/html;charset=utf8');
?>
