<?php 
session_start();//����session
include 'db.php';//�������ݿ������ļ�
//�ж��Ƿ��û���¼
if (empty($_SESSION['user']))
{
	echo "<script> location.href='login.php'</script>";
}
?>
<html>
  <head>
    <title>�޸�</title>
  </head>
  
  <body>
   <form name="form3" method="post">  
     <table border="0px" width="600px" height="400px" align="center" cellpadding="0px" cellspacing="0px">
       <tr>
         <td align="center"><b>�޸ļ۸�</b></td>
         <td><input type="text" name="price"/></td>
       </tr> 
       <tr>
         <td align="center"><b>�޸���ϸ��Ϣ</b></td>
         <td><input type="text" name="detail"/></td>
       </tr>
       <tr>
         <td align="center" colspan="2"><b>ע����Ʒ��Ų����޸�</b></td>
       </tr>    
       <tr>
         <td colspan="2" align="center">
            <input type="submit" name="sure" value="ȷ���޸�" />
            <input type="reset" value="����" />
         </td>        
       </tr>
     </table>
   </form>
  </body>
</html>
<?php 
if(isset($_POST['sure']))
{
	$price=$_POST['price'];
	$detail=$_POST['detail'];
	if ($price!="")
	{
		$sql="update goods set price='$price' where gid='$_GET[gid]'";
		$sqltool=new sql();
		$result=$sqltool->execute_dm($sql);
		if ($result)
		{
			echo "<script>alert('�޸ĳɹ�');location.href='manage.php'</script>";
		}
	}
	if($detail!="")
	{
		$sql="update goods set detail='$detail' where gid='$_GET[gid]'";
		$sqltool=new sql();
		$result=$sqltool->execute_dm($sql);
		if ($result)
		{
			echo "<script>alert('�޸ĳɹ�');location.href='manage.php'</script>";
		}
	}
	if($price==null&&$detail==null) 
		echo "<script>alert('��û���޸��κ�����');location.href='manage.php'</script>";
}
?>