<?php
session_start();
$value =$_SESSION['user'];

//����gid��ѯ��Ʒprice
$conn=mysqli_connect("localhost","root","","design") or die('����ʧ��');
mysqli_query($conn,"set names gb2312");
$gid=$_GET['gid'];

$sql="select * from goods where gid='$gid'";
$result=mysqli_query($conn, $sql);
$row=mysqli_fetch_assoc($result);
$price=$row['price'];

//����value��ѯnum
$sql1="select * from login where username='$value'";
$result1=mysqli_query($conn, $sql1);
$row1=mysqli_fetch_assoc($result1);
$num=$row1['num'];
$userid=$row1['id'];

//�������
$query="insert into infor values(NULL,'$userid','$gid','$num','$price')";
$result2=mysqli_query($conn, $query);
if (mysqli_affected_rows($conn)>0)
	echo "<script>alert('����ɹ���');location.href='system.php'</script>";
?>