<?php 
session_start();//开启session
include 'db.php';//引入数据库链接文件
//判断是否用户登录
if (empty($_SESSION['user']))
{
	echo "<script> location.href='login.php'</script>";
}

header('Content-Type:text/html;charset=utf8');
?>
<!DOCTYPE html>
<html>
  <head>
    <title>系统界面</title>
    <style>
		<?php
		include 'systemstyle.css';
		?>
    </style> 
  </head>
  <body>
  <form name="form1" method="post">
  <?php 
  $value= $_SESSION['user'];
  $conn=mysqli_connect("localhost","root","") or die('连接失败');
  mysqli_select_db($conn,"design") or die('数据库选择失败');
  mysqli_query($conn,"set names gb2312");
  $sql="select * from login where username='$value'";
  $result=mysqli_query($conn,$sql);
  $row=mysqli_fetch_assoc($result);
  ?>
        <div class ="logo" id="logo">网上买车系统</div>
        <div class="navigation" id="navigation">
		<b>欢迎用户<?php print ($value);?></b><a href='login.php'>返回登录页</a>
        </div>
        <div class="left" id="left">
        <table align="center" bgcolor="ffffff" height="100px">
        <tr>
        <td rowspan=3><input type="image" src="user.jpg" width="75" height="75" alt=""></td>
        <td>用户名:<?php echo $row['username'];?></td>
        </tr>
        <tr>
        <td>联系方式:<?php echo $row['num'];?></td>
        </tr>
        <tr>
        <td>用户id:<?php echo $row['id'];?></td>
        </tr>
        <tr>
        <td colspan="2"><input type="submit" name="infor" value="我的订单信息">
        </tr>
        </table>
        </div>
        <div class ="right" id="right">
        <form method="post">
  <table border="1" width = "100%">
  <tr>
  	 <td align="center">商品id</td>
     <td align="center">详细信息</td>
     <td align="center">商品图片</td>
     <td align="center">商品价格</td>
     <td align="center">操作</td>
  </tr>
  <?php
  $conn=mysqli_connect("localhost","root","") or die('连接失败');
  mysqli_select_db($conn,"design") or die('数据库选择失败');
  mysqli_query($conn,"set names gb2312");
  $sql="select * from goods";
  $result=mysqli_query($conn,$sql);
  ?>
  <?php while ($row=mysqli_fetch_assoc($result)){?>
  	<tr>
  	<td align="center"><?php echo $row['gid']?></td>
  	<td align="center"><?php echo $row['detail']?></td>
  	<td align="center"><input type="image" src='<?php echo $row['image']?>' width="200" height="100" ></td>
  	<td align="center"><?php echo $row['price']?></td>
  	<td align='center'><a href="buygoods.php?gid=<?php echo $row['gid']?>" onclick="return confirm('你确认购买吗？')">购买</a></td>
	</tr>
<?php }?>
  </table>
  </form>
        </div>
        <div class="bottom" id=bottom>Copyright ©2020-2100 版权所有</div>
        </form>
  </body>
</html>
<?php 
if (isset($_POST['infor']))
{
	echo "<script>location.href='myinfor.php'</script>";
}
?>