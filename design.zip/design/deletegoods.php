<?php
$conn=mysqli_connect("localhost","root","","design") or die('����ʧ��');
mysqli_query($conn,"set names gb2312");
$sql="delete from goods where gid='$_GET[gid]'";
$result=mysqli_query($conn, $sql);
if (mysqli_affected_rows($conn)>0)
	echo "<script>alert('ɾ���ɹ���');location.href='manage.php'</script>";
?>