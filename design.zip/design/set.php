<?php
$conn=mysqli_connect("localhost","root","") or die('����ʧ��');
mysqli_select_db($conn,"design") or die('���ݿ�ѡ��ʧ��');
mysqli_query($conn,"set names gb2312");
$sql="select * from login where id='$_GET[id]'";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($result);
if ($row['level']==0)
{
	require 'db.php';
	$sql="update login set level='1' where id='$_GET[id]'";
	$sqltool=new sql();
	$result=$sqltool->execute_dm($sql);
	if ($result)
		echo "<script>alert('ȡ���ɹ���');location.href='manage.php'</script>";
}
else
{
	require 'db.php';
	$sql="update login set level='0' where id='$_GET[id]'";
	$sqltool=new sql();
	$result=$sqltool->execute_dm($sql);
	if ($result)
	echo "<script>alert('���óɹ���');location.href='manage.php'</script>";
}
?>