<?php 
session_start();//����session
include 'db.php';//�������ݿ������ļ�
//�ж��Ƿ��û���¼
if (empty($_SESSION['user']))
{
	echo "<script> location.href='login.php'</script>";
}
?>
<html>
  <head>
    <title>�ҵĶ�����Ϣ</title>
  </head>
  <body background="background.jpg">
  <center><a href='system.php'>����ҳ</a></center>
  <table border="1" width = "100%">
  <tr>
  	 <td align="center">�û�id</td>
     <td align="center">��Ʒid</td>
     <td align="center">��ϵ��ʽ</td>
     <td align="center">�ɽ��۸�</td>
  </tr>
  <?php
  $value=$_SESSION['user'];
  $conn=mysqli_connect("localhost","root","") or die('����ʧ��');
  mysqli_select_db($conn,"design") or die('���ݿ�ѡ��ʧ��');
  mysqli_query($conn,"set names gb2312");
  $sql="select * from login where username='$value'";
  $result=mysqli_query($conn,$sql);
  $row=mysqli_fetch_assoc($result);
  $uid=$row ['id'];
  $sql1="select * from infor where userid='$uid'";
  $result1=mysqli_query($conn,$sql1);
  ?>
  <?php while ($row1=mysqli_fetch_assoc($result1)){?>
  	<tr>
  	<td align="center"><?php echo $uid?></td>
  	<td align="center"><?php echo $row1['gid']?></td>
  	<td align="center"><?php echo $row1['num']?></td>
  	<td align="center"><?php echo $row1['price']?></td>
  	</tr>
  <?php }?>
  </table>
  </body>
</html>