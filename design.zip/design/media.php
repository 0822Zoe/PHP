<?php
session_start();
$value=$_SESSION['user'];
$conn=mysqli_connect("localhost","root","","design");
mysqli_query($conn,"set names gb2312");
$sql="select level from login where username='$value'";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($result);
if($row['level']=='0')
{
	echo "<script>alert('����Ա�û���¼');location.href='manage.php'</script>";
}
else 
	echo "<script>alert('��ͨ�û���¼');location.href='system.php'</script>";
?>