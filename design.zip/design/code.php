<?php
session_start();
$code="";
$str = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";    
for($i=0;$i<4;$i++)
	$code.=$str{mt_rand(0,61)};
$image=imagecreatetruecolor(100,30);
$white=imagecolorallocate($image, 255, 255, 255);
imagefill($image, 0, 0, $white);
for($i=0;$i<100;$i++)
{
	$color=imagecolorallocate($image, rand(0,255), rand(0,255), rand(0,255));
    imagesetpixel($image, rand(0,100), rand(0,25), $color);
}
$red=imagecolorallocate($image, 255, 0, 0);

imagestring($image, 6, rand(0,65), rand(0,15), $code, $red);
header('Content-Type: image/png');
imagepng($image);
imagedestroy($image);
$_SESSION['code']=$code;
?>